#!/bin/bash
# Optional compatibility wrapper; this package builds directly with colcon.
set -euo pipefail

case "${1:-}" in
  ROS2|humble|jazzy) shift ;;
  ROS1)
    echo "This package now supports ROS 2 only." >&2
    exit 1
    ;;
esac

package_dir="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
cd -- "${package_dir}/../.."
exec colcon build --packages-select livox_ros_driver2 "$@"
